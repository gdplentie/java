package entidade;

public class Retangulo {
    private String nome;
    private String cor;
    private double altura;
    private double largura;


    public double area(){
        return this.altura*this.largura;
    }

    public double diagonal(){
        return Math.sqrt((this.altura*this.altura)+(this.largura*this.largura));
    }

    public Retangulo(String nome, String cor, double altura, double largura) {
        this.nome = nome;
        this.cor = cor;
        this.altura = altura;
        this.largura = largura;
    }

    @Override
    public String toString(){
        return String.format("Nome: %s ; Cor: %s ; Largura: %.1f ; Altura: %.1f",this.nome,this.cor,this.largura,this.altura);
    }
}
