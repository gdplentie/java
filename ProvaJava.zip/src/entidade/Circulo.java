package entidade;

public class Circulo {
    private String nome;
    private String cor;
    private double raio;

    public double area(){
        return Math.PI*this.raio*this.raio;
    }

    public double diametro(){
        return 2*this.raio;
    }

    public Circulo(String nome, String cor, double raio) {
        this.nome = nome;
        this.cor = cor;
        this.raio = raio;
    }

    @Override
    public String toString(){
        return String.format("Nome: %s ; Cor: %s ; Raio: %.1f",this.nome,this.cor,this.raio);
    }
}
