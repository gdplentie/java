package aplicacao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import entidade.*;

public class Principal {
    public static String obj="objetos.txt";

    public static void main(String[] args) throws IOException {
        List<Retangulo> retangulos=new ArrayList<Retangulo>();
        List<Circulo> circulos=new ArrayList<Circulo>();

        Scanner leitor=new Scanner(System.in);

        char leitura;
        int leitura_n;

        boolean saiu=false;
        boolean objetosGerados=false;

        while(!saiu){
            System.out.print("O que deseja fazer?\n1-Gerar objetos\n2-Listar as áreas dos triângulos\n3-Listar as áreas dos círculos\n4-Listar as diagonais dos retângulos\n5-Listar os diâmetros dos círculos\n6- Sair\n\n->");

            leitura=leitor.nextLine().charAt(0);
            leitura_n=leitura-'0';

            if(!objetosGerados && leitura_n<=5 && leitura_n>=2){
                System.out.println("Erro: os objetos ainda não foram gerados, gere-os primeiro");
                continue;
            }

            if(objetosGerados && leitura_n==1){
                System.out.println("Erro: os objetos já foram gerados");
                continue;
            }

            switch(leitura){
                case '1':
                    gerarObjetos(retangulos,circulos);
                    objetosGerados=true;
                    System.out.println("Objetos gerados com sucesso!");
                    break;

                case '2':
                    for(Retangulo r:retangulos){
                        System.out.println(r+" ; Área: "+String.format("%.1f",r.area()));
                    }
                    break;

                case '3':
                    for(Circulo c:circulos){
                        System.out.println(c+" ; Área: "+String.format("%.1f",c.area()));
                    }
                    break;

                case '4':
                    for(Retangulo r:retangulos){
                        System.out.println(r+" ; Diagonal: "+String.format("%.1f",r.diagonal()));
                    }
                    break;

                case '5':
                    for(Circulo c:circulos){
                        System.out.println(c+" ; Diâmetro: "+String.format("%.1f",c.diametro()));
                    }
                    break;

                case '6':
                    saiu=true;
                    break;

                default:
                    System.out.println("Erro: Opção inválida, tente novamente");
            }

            System.out.println("\n");
        }

        System.out.println("Obrigado por usar o programa!");
    }

    public static void gerarObjetos(List<Retangulo>r, List<Circulo>c) throws IOException {
        BufferedReader br=new BufferedReader(new FileReader(Principal.obj));

        String linha;

        while((linha=br.readLine())!=null){
            String dados[]=linha.split(";");

            if(dados[0].equals("Retangulo")){
                String nome="Retângulo";
                String cor=dados[1];
                double largura=Double.parseDouble(dados[2]);
                double altura=Double.parseDouble(dados[3]);

                r.add(new Retangulo(nome,cor,largura,altura));
            }else if(dados[0].equals("Circulo")){
                String nome="Círculo";
                String cor=dados[1];
                double raio=Double.parseDouble(dados[2]);

                c.add(new Circulo(nome,cor,raio));
            }
        }

    }
}
